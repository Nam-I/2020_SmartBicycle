package com.example.smartbicycle;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
//    private static final String TAG = "LoginActivity";
//    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize Firebase Auth
        //mAuth = FirebaseAuth.getInstance();

        //findViewById(R.id.login_button).setOnClickListener(onClickListener);
    }

//    @Override
//    public void onStart() {
//        super.onStart();
//        // Check if user is signed in (non-null) and update UI accordingly.
//        FirebaseUser currentUser = mAuth.getCurrentUser();
//    }

//    View.OnClickListener onClickListener = new View.OnClickListener() {
//        @Override
//        public void onClick(View view) {
//            switch (view.getId()){
//                case R.id.login_button:
//                    Intent intent = new Intent(getApplicationContext(), SpeedometerActivity.class);
//                    startActivity(intent);
//                    break;
//            }
//        }
//    };

    public void sign_up(View v) {
        Intent intent = new Intent(getApplicationContext(), SignupActivity.class);
        startActivity(intent);
    }
    public void main_speed(View v){
        Intent intent = new Intent(getApplicationContext(), SpeedometerActivity.class);
        startActivity(intent);
    }
}